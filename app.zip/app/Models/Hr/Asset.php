<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class Asset extends Model
{
    protected $table=  'hr_asset_assign';
    
    public $timestamps= false;
}
