<?php

namespace App\Models\Hr;

use App\Models\Hr\BuyerTemplateDetails;

use Illuminate\Database\Eloquent\Model;

class BuyerTemplateDetails extends Model
{
    
    protected $table= 'hr_buyer_template_detail';
    public $timestamps= false;


   

}
