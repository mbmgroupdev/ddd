<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class Attendace extends Model
{
    protected $table = "hr_attendance";
    
    public $timestamps = false;
}
