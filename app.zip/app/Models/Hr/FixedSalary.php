<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class FixedSalary extends Model
{

    protected $table = "hr_fixed_emp_salary";

    public $timestamps = false;

   
    
}
