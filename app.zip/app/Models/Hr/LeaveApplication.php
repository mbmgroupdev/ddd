<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class LeaveApplication extends Model
{
    protected $table = 'hr_leave_application';

    public $timestamps = false;
}
