<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class MaternityLeave extends Model
{
    protected $table = "hr_maternity_leave";

    public $timestamps = false;
}
