<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class MapCostSubSection extends Model
{
    protected $table = "hr_cost_mapping_sub_section";
    public $timestamps = false;
}
