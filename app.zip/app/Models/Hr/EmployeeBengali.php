<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class EmployeeBengali extends Model
{
    protected $table = "hr_employee_bengali";

    public $timestamps = false;
}
