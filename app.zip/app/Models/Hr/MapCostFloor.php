<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class MapCostFloor extends Model
{
    protected $table= 'hr_cost_mapping_floor';
    public $timestamps= false;
}
