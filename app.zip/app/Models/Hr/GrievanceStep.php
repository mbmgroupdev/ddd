<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class GrievanceStep extends Model
{

    protected $table = "hr_grievance_steps";

    public $timestamps = false;
    
}
