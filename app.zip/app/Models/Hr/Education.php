<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class Education extends Model
{
    protected $table= "hr_education";
    public $timestamps= false;
}
