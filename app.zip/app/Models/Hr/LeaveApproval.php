<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class LeaveApproval extends Model
{
    protected $table = 'hr_leave_approval';

    public $timestamps = false;
}
