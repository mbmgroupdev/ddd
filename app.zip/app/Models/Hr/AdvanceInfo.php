<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class AdvanceInfo extends Model
{
    protected $table= "hr_as_adv_info";
    public $timestamps = false;
    protected $guarded = [];
}
