<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class StatusTracker extends Model
{
	protected $table = "hr_associate_status_tracker";

    public $timestamps = false; 
}
