<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class AttandancedataTemp extends Model
{
    protected $table= "hr_att_data_temp";
    public $timestamps = false;
    protected $guarded = [];
}
