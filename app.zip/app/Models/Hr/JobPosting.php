<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class JobPosting extends Model
{
    protected $table= 'hr_job_posting';
    public $timestamps= false;
}
