<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class SalaryAddDeduct extends Model
{
    protected $table = 'hr_salary_add_deduct';
    public $timestamps = false;

    
}
