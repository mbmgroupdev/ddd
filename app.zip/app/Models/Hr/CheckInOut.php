<?php

namespace App\MOdels\Hr;

use Illuminate\Database\Eloquent\Model;

class CheckInOut extends Model
{
    protected $table = "checkinout";
    public $timestamps = false; 
}
