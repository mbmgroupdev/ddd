<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class Cv extends Model
{
    //
}
