@extends('hr.index')
@section('content')
	{{$count}}
@endsection