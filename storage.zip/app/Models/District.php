<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class District extends Model
{
	protected $table = "hr_dist";
    public $timestamps = false; 
}
