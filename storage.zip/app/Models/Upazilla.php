<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Upazilla extends Model
{
    protected $table = "hr_upazilla";

    public $timestamps = false; 
}
