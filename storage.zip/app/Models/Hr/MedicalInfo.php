<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class MedicalInfo extends Model
{
    protected $table= "hr_med_info";
    public $timestamps = false;
    protected $guarded = [];

}
