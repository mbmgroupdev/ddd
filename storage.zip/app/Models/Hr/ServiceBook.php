<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class ServiceBook extends Model
{
    protected $table=  'hr_service_book';
    
    public $timestamps= false;
}
