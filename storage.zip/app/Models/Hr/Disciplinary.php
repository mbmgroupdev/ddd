<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class Disciplinary extends Model
{
    protected $table= 'hr_dis_rec';
    public $timestamps= false;
}
