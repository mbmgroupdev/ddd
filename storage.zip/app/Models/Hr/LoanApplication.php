<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class LoanApplication extends Model
{
    protected $table = "hr_loan_application";

    public $timestamps = false;
}
