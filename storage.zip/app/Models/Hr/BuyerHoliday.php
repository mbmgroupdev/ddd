<?php

namespace App\Models\Hr;

use App\Models\Hr\BuyerHoliday;

use Illuminate\Database\Eloquent\Model;

class BuyerHoliday extends Model
{
    
    protected $table= 'hr_buyer_holiday';
    public $timestamps= false;


   

}
