<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class EducationResult extends Model
{
    protected $table= "hr_education_result";
    public $timestamps= false;
}
