<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class Earnleave extends Model
{
    protected $table = "hr_earn_leave";

    public $timestamps = false;
}
