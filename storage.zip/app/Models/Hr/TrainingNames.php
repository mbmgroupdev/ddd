<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class TrainingNames extends Model
{
    protected $table = 'hr_training_names';

    public $timestamps = false;
}
