<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class OtherBenefitAssign extends Model
{
    protected $table = "hr_other_benefit_assign";

    public $timestamps = false;
}
