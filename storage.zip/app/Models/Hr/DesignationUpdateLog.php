<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class DesignationUpdateLog extends Model
{
    protected $table= 'hr_designation_update_log';
    public $timestamps= false;
}
