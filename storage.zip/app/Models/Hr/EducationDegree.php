<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class EducationDegree extends Model
{
    protected $table= "hr_education_degree_title";
    public $timestamps= false;
}
