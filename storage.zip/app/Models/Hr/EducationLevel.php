<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class EducationLevel extends Model
{
    protected $table= "hr_education_level";
    public $timestamps= false;
}