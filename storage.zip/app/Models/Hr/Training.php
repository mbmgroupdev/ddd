<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class Training extends Model
{
    protected $table = 'hr_training';

    public $timestamps = false;
}
