<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class GrievanceAppeal extends Model
{
    protected $table = "hr_grievance_appeal";

    public $timestamps = false;
}
