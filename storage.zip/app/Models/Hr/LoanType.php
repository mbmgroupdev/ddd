<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class LoanType extends Model
{
    protected $table = "hr_loan_type";

    public $timestamps = false;
}
