<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class SalaryStructure extends Model
{
    protected $table = 'hr_salary_structure';
    public $timestamps = false;
}
