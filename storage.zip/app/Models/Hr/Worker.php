<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class Worker extends Model
{
    protected $table= "hr_worker_recruitment";
    public $timestamps= false; 
}
