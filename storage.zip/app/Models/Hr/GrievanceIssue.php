<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class GrievanceIssue extends Model
{
    protected $table = "hr_grievance_issue";

    public $timestamps = false;
    
}
