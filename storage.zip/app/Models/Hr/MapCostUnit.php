<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class MapCostUnit extends Model
{
    protected $table= 'hr_cost_mapping_unit';
    public $timestamps= false;
}
