<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class IncrementType extends Model
{
    protected $table = "hr_increment_type";

    public $timestamps = false;
}
