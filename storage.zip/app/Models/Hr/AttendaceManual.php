<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class AttendaceManual extends Model
{
    protected $table = "hr_attendance_manual";
    
    public $timestamps = false;
}
