<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class Ot extends Model
{
    protected $table = 'hr_ot';
    public $timestamps = false;
}
