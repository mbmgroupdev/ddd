<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class HrAttendanceCeil extends Model
{
    protected $table = "hr_attendance_ceil";

    public $timestamps = false;

    
}
