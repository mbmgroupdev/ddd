<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class Letters extends Model
{
    protected $table = 'hr_letter';

    public $timestamps = false;
}
