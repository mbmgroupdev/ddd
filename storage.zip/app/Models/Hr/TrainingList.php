<?php

namespace App\Models\Hr;

use Illuminate\Database\Eloquent\Model;

class TrainingList extends Model
{
    protected $table = 'hr_training_list';

    public $timestamps = false;
}
